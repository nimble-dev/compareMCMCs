library(testthat)
library(compareMCMCs)

test_check("compareMCMCs")
